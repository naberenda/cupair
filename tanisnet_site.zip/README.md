# TanişNet - Static Starter Site

Bu paket `index.html` dosyasını içerir. GitHub Pages ile telefon/günlük kullanım için hızlıca yayınlamak üzere hazırlanmıştır.

## GitHub Pages - Kısa Adımlar (Telefon)
1. GitHub hesabına giriş yap veya oluştur.
2. Yeni bir repository oluştur (ör. `tanisma-sitesi`) ve public seç.
3. 'Add file' → 'Upload files' ile bu klasördeki `index.html` dosyasını yükle.
4. Commit changes yap.
5. Repository -> Settings -> Pages -> Source: `main` branch, folder: `/root` seç ve Save.
6. Birkaç dakika içinde `https://kullaniciadi.github.io/repo-ismi/` şeklinde yayınlanır.

## Notlar
- Bu sürüm frontend (statik) bir demo'dur. Gerçek mesajlaşma, kullanıcı eşleştirme, ödeme ve veri saklama için bir backend (Sunucu) gereklidir.
- Fotoğraf bulanık/netleşme şu an **sadece görsel simülasyondur**. Gerçek kullanımda net fotoğraf gösterimi eşleşme doğrulaması ile backend'de kontrol edilmelidir.
